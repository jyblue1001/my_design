make
make clean
